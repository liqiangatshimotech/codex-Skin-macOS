# Doraemon Codex Skin for macOS

请先阅读 [安装说明.md](./安装说明.md)，然后双击 `安装机器猫主题.command`。

分享时请发送完整文件夹或项目生成的 ZIP，不要只发送 `.command` 文件。
